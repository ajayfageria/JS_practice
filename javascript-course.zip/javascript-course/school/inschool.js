export function inSchool() {
    console.log("i am from school function");
}

function inSchool1() {
    console.log("i am from school1 function");
}
export default inSchool1;