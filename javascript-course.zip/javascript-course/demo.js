//currying function
// function multiply(num1) {
//     return (num2) => {
//         return num1 * num2;
//     }
// }  
//just
// const getNumber = multiply(5);
// console.log(getNumber(3))

// const users = [{ name: "ajay", profession: "developer", age: 24 }, { name: "mandeep", profession: "tester", age: 25 }]
//     // const getUsers = users.map(data => data.name)
//     // console.log(getUsers);
// function mapKeyWithObject(key) {
//     return object => {
//         return object[key];
//     }

// }

// console.log(users.map(mapKeyWithObject('name')))
// const myButton = document.getElementById("btn");
// myButton.addEventListener('click', onFunc);
// setTimeout(() => {
//     myButton.removeEventListener('click', onFunc)
// }, 2000)

// function onFunc(event) {
//     console.log(event);
//     alert("hello world!!!")
// }
// const form = document.getElementById("myform");
// form.addEventListener('submit', onSubmit)

// function onSubmit(event) {
//     event.preventDefault();
//     console.log(event)

// }

// let myid = Symbol('idqwerty');
// let name2 = 'id';
// let name3 = 'myname'
// console.log(name2 == name2)
// let obj = {
//     [myid]: 'nameid',
//     city: "hisar",
//     village: "siswala",
//     pin: 125001
// }
// const mySymbol = Object.getOwnPropertySymbols(obj)
// console.log(mySymbol)
// questionsArray = ["1.first question", "2.second question", "3.third question"]
// let i = 0;
// document.getElementById("preBtn").disabled = true;

// function next() {
//     document.getElementById("questionList").innerText = questionsArray[i];
//     i++;
//     if (i == questionsArray.length) {
//         document.getElementById("nxtBtn").disabled = true;
//         document.getElementById("preBtn").disabled = false;

//     } else {
//         document.getElementById("preBtn").disabled = false;
//         document.getElementById("nxtBtn").disabled = false;

//     }
// }

// function back() {
//     document.getElementById("questionList").innerText = questionsArray[i - 2];
//     i--;
//     if (i - 2 < 0) {
//         document.getElementById("preBtn").disabled = true;
//         document.getElementById("nxtBtn").disabled = false;

//     } else {
//         document.getElementById("preBtn").disabled = false;
//         document.getElementById("nxtBtn").disabled = false;

//     }
// }
// sum = (number1) => (number2) => number2 ? sum(number1 + number2) : number1;



// function sum(number1) {
//     return (number2) => {
//         return number2 ? sum(number1 + number2) : number1;

//     }
// }

// sum = (a) => (b) => b ? sum(a + b) : a;

// console.log(sum(10)(12)(2)(3)())
// function fun1() {
//     setTimeout(() => {
//         console.log("🤡")
//     }, 3000)

// }

// async function fun2() {
//     return new Promise((resolve, reject) => {
//         if (true) {
//             resolve("🤡");
//         }
//     })
// }
// fun2().then((data) => {
//     console.log(data)
// });

// a = 15;
// b = 10;
// // a = a + b; //110
// // b = a - b; //110-100=10
// // a = a - b //110-10=110
// b = a + b; //25
// a = b - a //25-15=10
// b = b - a //25-10=15


// console.log(a, b);
//HOF vs CB function

// function sum(a, b) {
//     return a + b;
// }

// function mul(a, b) {
//     return a * b;
// }

// function subs(a, b) {
//     return Math.abs(a - b);
// }

// function div(a, b) {
//     return a / b;
// }
// console.log(sum(10, 20));
// console.log(mul(10, 20));
// console.log(subs(10, 20));
// console.log(div(10, 20));

// const calculator = (a, b, op) => {
//         return op(a, b);
//     }
// calculator(a, b, op);
// console.log(calculator(2, 3, sum))

// list = [10, 20, 30, 40, 50]
// sum = list.reduce((acc, num) => {
//     console.log(acc, num)
//     return acc + num;
// })
// console.log(sum);
// const list = [
//         ["list1", "list2"],
//         ["list3", "list4"],
//         ["list5", "list6", ["list7", "list8"]]
//     ]
//     // console.log(list.reduce((acc, arr) => {

// //     return acc.concat(arr);
// // }))
// console.log(list.flat(2))
var d = new Date();
console.log(d.getSeconds())