import axios from 'axios';
const baseUrl='http://reqres.in/api/users'
axios.get(baseUrl).then((data)=>{
    console.log(data);
}).catch((error)=>{
    console.log(error);

})