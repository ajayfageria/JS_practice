export function collegeFunction() {
    console.log("i am from college function")
}